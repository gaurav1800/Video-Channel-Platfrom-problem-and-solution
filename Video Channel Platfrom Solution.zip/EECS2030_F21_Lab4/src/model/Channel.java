package model;

public class Channel {
	private String channelName;
	
	private int nof; // no. of followers
	private int maxFollowers;
	
	private Follower[] followers;
	private ChannelStatistics[] channelStats;
	
	private int nov; // no. of videos
	private int maxVideos;
	protected String[] videos;
	
	
	private Channel() {
		//do nothing; just to initialize the variables to their default values
	}
	
	public Channel(String channelName, int maxFollowers, int maxVideos) {
		this.channelName = channelName;
		this.maxFollowers = maxFollowers;
		this.maxVideos = maxVideos;
		
		
		followers = new Follower[maxFollowers];
		channelStats = new ChannelStatistics[maxFollowers];
		videos = new String[maxVideos];
		
	}
	
	public String getName() {
		return channelName;
	}
	
	public void releaseANewVideo(String vid) {
		videos[nov] = vid;
		nov++;
		
		for(int i = 0; i < nof; i++) {
			followers[i].updateRecommendedVids(vid);
		}
	}
	

	public String[] getVideos() {
		return videos;
	}

	public void setStats(String follower, int minutes) {
		for(int i = 0; i < nof; i++) {
			channelStats[i].setStats(minutes);
		}
	}

	public String getStats(String follower) {
		for(int i = 0; i < nof; i++) {
			if(follower.equals(followers[i].getName())) {
				return channelStats[i].getStats();
			}
		}
		return "";
	}
	
	public void follow(Follower f) {
		followers[nof] = f;
		f.channels[f.noc] = this;
		channelStats[nof] = new ChannelStatistics();
		
		
		nof++;
		f.noc++;
		
		
	}
	
	public void unfollow(Follower f) {
		for(int i = 0; i < nof; i++) {
			if(followers[i] == f) {
				for(int j = i; j < nof - 1; j++) {
					followers[j] = followers[j+1];
				}
				followers[nof] = null;
				nof--;
			}
		}
		
		
		for(int i = 0; i < f.noc; i++) {
			if(f.channels[i] == this) {
				for(int j = i; j < f.noc - 1; j++) {
					f.channels[j] = f.channels[j+1];
				}
				f.channels[f.noc] = null;
				f.noc--;
			}
			else {
				continue;
			}
		}
	}
	
	
	
	public String toString() {
		String s = this.channelName + " released ";
		if(nov == 0) {
			s += "no videos and" ;
		}
		else {
			s += "<";
			for(int i = 0; i < nov; i++) {
				if(i != 0) {
					s += ", ";
				}
				s += videos[i];
			}
			s += "> and";
		}
		if (nof == 0) {
			s += " has no followers.";
		}
		else {
			s += " is followed by [";
			for(int i = 0; i < nof; i++) {
				if(i != 0) {
					s += ", ";
				}
				s += followers[i].getName();
			}
			s += "].";
		}
		return s;
	}
	

}

