package model;

public class Follower{
	
	protected String name;

	protected int maxChannels;
	protected int noc; // no. of channels
	
	protected String[] recommendedVids;
	protected int maxrv; // max recommended videos
	protected int norv; //no. of recommended videos
	
	protected Channel[] channels;
	

	
	public Follower() {
		// do nothing; just to initialize the variables to their default values
	}
	
	
	// For subscriber class
	public Follower(String name, int maxChannels, int maxrv) {
		this.name = name;
		this.maxChannels = maxChannels;
		this.maxrv = maxrv;
		channels = new Channel[maxChannels];
	}
	
	
	// For monitor class
	public Follower(String name, int maxChannels) {
		this.name = name;
		this.maxChannels = maxChannels;
		channels = new Channel[maxChannels];
	}
	
	public String getName() {
		return name;
	}
	
	public void updateRecommendedVids(String vid) { }

	

}
