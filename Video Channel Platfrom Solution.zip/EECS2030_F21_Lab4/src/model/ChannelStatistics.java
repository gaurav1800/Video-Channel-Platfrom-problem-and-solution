package model;

public class ChannelStatistics {

	private int numOfViews;
	private int maxWatchTime;
	private double aveWatchTime;
	private int totalWatchTime;

	public ChannelStatistics() {
		// do nothing; just to initiate the variables to their default values
	}

	public void setStats(int minutes) {
		numOfViews++;
		totalWatchTime += minutes;
		
		if(minutes > maxWatchTime) {
			maxWatchTime = minutes;
		}

		aveWatchTime = (double) totalWatchTime / numOfViews;
	}

	public String getStats() {
		if (numOfViews == 0) {
			return "";
		}

		return " {#views: " + numOfViews + ", max watch time: " + maxWatchTime + ", avg watch time: "
				+ String.format("%.2f", aveWatchTime) + "}";
	}
}
