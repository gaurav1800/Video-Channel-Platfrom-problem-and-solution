package model;

public class Subscriber extends Follower{
	
	private int maxrv;
	private int norv; // no. of recommended videos
	
	
	public Subscriber() {
		// do nothing; just to initialize the variables to their default values
	}
	
	public Subscriber(String name, int maxChannels, int maxrv) {
		super(name, maxChannels, maxrv);
		
		this.name = "Subscriber " + name;
		this.maxChannels = maxChannels;
		
		this.maxrv = maxrv;
		
		this.recommendedVids = new String[maxrv];
	}
	
	public String toString() {
		String s = this.name + " follows ";
		
		if(noc == 0) {
			s += "no channels and ";
		}
		else {
			s += "[";
			for(int i = 0; i < noc; i++) {
				if(i != 0) {
					s += ", ";
				}
				s += channels[i].getName();
			}
			s += "] and ";
		}
		if(norv == 0) {
			s += "has no recommended videos.";
		}
		else {
			s += "is recommended <";
			for(int i = 0; i < norv; i++) {
				if(i != 0) {
					s += ", ";
				}
				s += recommendedVids[i];
			}
			s += ">.";
		}
		return s;
	}
	
	public void updateRecommendedVids(String vid) {
		recommendedVids[norv] = vid;
		norv++;
	}
	
	public void watch(String vid, int minutes) {
		for(int i = 0; i < noc; i++) {
			String[] channelVids = channels[i].getVideos();
			int numOfChannelVids = channelVids.length;
			for(int j = 0; j < numOfChannelVids; j++) {
				if(vid.equals(channelVids[j])) {
					channels[i].setStats(this.name, minutes);
				}
			}
		}
	}

}










