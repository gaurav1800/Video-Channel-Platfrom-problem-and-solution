package model;

public class Monitor extends Follower{
	
	public Monitor() {
		// do nothing; just to initialize the variables to their default values
	}
	
	public Monitor(String name, int maxChannels) {
		super(name, maxChannels);
		this.name = "Monitor " + name;
		this.maxChannels = maxChannels;
		channels = new Channel[maxChannels];
	}
	
	
	public String toString() {
		String s = getName() + " follows ";
		if(noc == 0) {
			s += "no channels.";
		}
		else {
			s += "[";
			for(int i = 0; i < noc; i++) {
				if(i != 0) {
					s += ", ";
				}
				s += channels[i].getName();
				s += channels[i].getStats(getName());
			}
			s += "].";
		}
		
		return s;
	}

	
}
